# PrestaShop1.6 Newsman Remarketing
[Newsman](https://www.newsmanapp.com) plugin for PrestaShop.

This is the easiest way to connect your Shop with [Newsman](https://www.newsmanapp.com).
Generate an API KEY in your [Newsman](https://www.newsmanapp.com) account, install this plugin and you will be able to track your shop customers.

# Installation
Manual installation:
Copy the `newsmanremarketing` directory from this repository to your `modules` shop directory.

# Setup
1. Fill in your Newsman Remarketing Tracking ID
![](https://raw.githubusercontent.com/Newsman/PrestaShop1.6-Newsman-Remarketing/master/assets/1.jpg)

2. Enable and click save


