<?php
/**
 * Copyright 2019 Dazoot Software
 *
 * NOTICE OF LICENSE
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @author    Lucian for Newsman
 * @copyright 2019 Dazoot Software
 * @license   http://www.apache.org/licenses/LICENSE-2.0
 */
class AdminNewsmanAjaxController extends ModuleAdminController
{
	public $ssl = true;

	public function init()
	{
		$order = new Order((int)Tools::getValue('orderid'));
		$context = Context::getContext();
		if (Validate::isLoadedObject($order) && (isset($context->employee->id) && $context->employee->id))
		{
			/*
			Db::getInstance()->execute('UPDATE `'._DB_PREFIX_.'newsmanremarketing` SET sent = 1, date_add = NOW() WHERE id_order = '.(int)Tools::getValue('orderid'));
			*/
			die('OK');
		}
		die('KO');
	}
}
